package cibertec.edu.pe.viaje;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViajeApplicationTests {

	@Test
	void contextLoads() {
	}

}
