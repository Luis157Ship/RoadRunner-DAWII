package cibertec.edu.pe.pago;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PagoApplicationTests {

	@Test
	void contextLoads() {
	}

}
