package cibertec.edu.pe.pasaje;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PasajeApplication {

	public static void main(String[] args) {
		SpringApplication.run(PasajeApplication.class, args);
	}

}
