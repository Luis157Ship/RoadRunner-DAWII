package cibertec.edu.pe.pasaje;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PasajeApplicationTests {

	@Test
	void contextLoads() {
	}

}
