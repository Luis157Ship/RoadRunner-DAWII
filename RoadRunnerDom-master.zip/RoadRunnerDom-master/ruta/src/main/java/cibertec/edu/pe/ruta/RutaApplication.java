package cibertec.edu.pe.ruta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RutaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RutaApplication.class, args);
	}

}
