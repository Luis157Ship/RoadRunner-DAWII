package cibertec.edu.pe.ruta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RutaApplicationTests {

	@Test
	void contextLoads() {
	}

}
